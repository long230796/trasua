/**
 * C3 charts page
 */
(function() {
  'use strict';

  /******** Chart 1 ********/
  $.fn.thuNhapChart = function(thunhapdata) {
    console.log(thunhapdata.thunhap)
    var chart = c3.generate({
      data: {
        columns: [
          thunhapdata.thunhap
          // ['data2', 0, thunhapdata.thunhapngay]
        ]
      }
    });
    // setTimeout(function() {
    //   chart.load({
    //     columns: [
    //       ['data1', 230, 190, 300, 500, 300, 400, 300, 200, 250]
    //     ]
    //   });
    // }, 1000);
    // setTimeout(function() {
    //   chart.load({
    //     columns: [
    //       ['data3', 130, 150, 200, 300, 200, 100, 150, 160, 100]
    //     ]
    //   });
    // }, 1500);
    // setTimeout(function() {
    //   chart.unload({
    //     ids: 'data1'
    //   });
    // }, 2000);

  };


  /******** Chart 2 ********/

  // c3.generate({
  //   bindto: '#chart2',
  //   data: {
  //     x: 'x',
  //     columns: [
  //       ['London, UK', 'Paris, France', 'Milan, Italy', 'Frankfurt, Germany', 'Chicago, USA', 'Paris, France', 'Milan, Italy', 'Frankfurt, Germany', 'Chicago, USA'],
  //       ['data1', 30, 200, 100, 400, 150, 250, 50, 100, 250]
  //     ],
  //     type: 'bar'   
  //   },
  //   bar: {
  //     width: {
  //       ratio: 0.5
  //     }
  //   }
  // });
  $.fn.tonKhoChart = function(data) {
    console.log(data.soluongtieuthu)
    var chart = c3.generate({
      bindto: '#chart2',
      data: {
        x: 'x',
        columns: [
        data.tennguyenlieu,
        data.soluongtieuthu
        ],
        type: 'bar'
      },
      axis: {
       
        x: {
          type: 'category'
        }
      },
      grid: {
        y: {
          show: true
              // lines: [
              //     { value: 180, text: 'Sales target', position: 'middle' },
              //     { value: 250, text: 'Production target', position: 'end'}
              //     ]
            }
          }
        });
    
  }


  $.fn.biendonggiaChart = function(data) {
    console.log(data.soluongtieuthu)
    var chart = c3.generate({
      bindto: '#chart2',
      data: {
        x: 'x',
        columns: [
        data.ngaybiendong,
        data.biendonggia
        ],
        type: 'bar'
      },
      axis: {
       
        x: {
          type: 'category'
        }
      },
      grid: {
        y: {
          show: true
              // lines: [
              //     { value: 180, text: 'Sales target', position: 'middle' },
              //     { value: 250, text: 'Production target', position: 'end'}
              //     ]
            }
          }
        });
    
  }
})
();
