/**
 * Sweetalerts demo page
 */
(function($) {
  'use strict';

  $('.demo1').on('click', function() {
    swal('Here\'s a message!');
  });

  $('.demo2').on('click', function() {
    swal({
      title: 'Auto close alert!',
      text: 'I will close in 2 seconds.',
      timer: 2000
    });
  });

  $('.demo3').on('click', function() {
    swal('Here\'s a message!', 'It\'s pretty, isn\'t it?');
  });

  $('.demo4').on('click', function() {
    swal('Good job!', 'You clicked the button!', 'success');
  });

  $('.demo5').on('click', function() {
    swal({
      title: 'Bạn có muốn khóa tài khoản này?',
      text: 'Tài khoản này sẽ bị khóa tạm thời',
      type: 'warning',
      showCancelButton: true,
      confirmButtonColor: '#e1300e',
      confirmButtonText: 'Chấp nhận!',
      closeOnConfirm: false
    }, function() {
      angular.element('#angularPart').scope().confirmLock()
      .then(function (res) {
        // swal('Đã khóa!', 'Khóa thành công', 'success');
        swal({
          title: 'Đã khóa!',
          text: 'Khóa thành công',
          type: 'success'
        }, function () {
          window.location = "danhsachtaikhoan";
          
        })
      })
      .catch(function(err) {
        swal('Thất bại', 'Có lỗi xảy ra vui lòng kiểm tra lại', 'warning')
      })
    });
  });

  $('.demo55').on('click', function() {
    swal({
      title: 'Mở tài khoản này?',
      text: 'Tài khoản này sẽ được mở',
      type: 'warning',
      showCancelButton: true,
      confirmButtonColor: '#e1300e',
      confirmButtonText: 'Chấp nhận!',
      closeOnConfirm: false
    }, function() {
       angular.element('#angularPart').scope().confirmUnlock()
      .then(function (res) {
        
        // swal('Mở thành công!', '', 'success');
        swal({
          title: 'Mở thành công!',
          text: '',
          type: 'success'
        }, function () {
          window.location = "danhsachtaikhoan";
          
        })
      })
      .catch(function(err) {
        swal('Thất bại', 'Có lỗi xảy ra vui lòng kiểm tra lại', 'warning')
      })
      
    });
  });

  $('.demo66').on('click', function() {
    swal({
      title: 'Lưu thay đổi?',
      text: 'Thay đổi này sẽ được lưu',
      type: 'warning',
      showCancelButton: true,
      confirmButtonColor: '#e1300e',
      confirmButtonText: 'Chấp nhận!',
      closeOnConfirm: false
    }, function() {
       angular.element('#angularPart').scope().confirmDone()
      .then(function (res) {
        
        swal({
          title: 'Lưu thành công!',
          text: '',
          type: 'success'
        }, function () {
          window.location = "danhsachtaikhoan";
          
        })
      })
      .catch(function(res) {
        swal(res, 'Vui lòng kiểm tra lại', 'warning')
      })
      
    });
  });

  $('.deleteTaikhoan').on('click', function() {
    swal({
      title: 'Xóa khoản này?',
      text: 'Xóa tài khoản này đồng ý với việc xóa nhân viên thuộc tài khoản này',
      type: 'warning',
      showCancelButton: true,
      confirmButtonColor: '#e1300e',
      confirmButtonText: 'Chấp nhận!',
      closeOnConfirm: false
    }, function() {
       angular.element('#angularPart').scope().confirmDeleteTaikhoan()
      .then(function (res) {
        
        // swal('Mở thành công!', '', 'success');
        swal({
          title: 'Xóa thành công!',
          text: '',
          type: 'success'
        }, function () {
          window.location = "danhsachtaikhoan";
          
        })
      })
      .catch(function(err) {
        swal('Thất bại', err, 'warning')
      })
      
    });
  });


  $('.deleteNguyenlieu').on('click', function() {
    swal({
      title: 'Bạn có muốn xóa nguyên liệu này?',
      text: 'Nguyên liệu này sẽ bị xóa',
      type: 'warning',
      showCancelButton: true,
      confirmButtonColor: '#e1300e',
      confirmButtonText: 'Chấp nhận!',
      closeOnConfirm: false
    }, function() {
      angular.element('#angularPart').scope().confirmDelete()
      .then(function (res) {
        // swal('Đã khóa!', 'Khóa thành công', 'success');
        swal({
          title: 'Đã xóa!',
          text: 'Xóa thành công',
          type: 'success'
        }, function () {
          window.location = "danhsachnguyenlieu";
          
        })
      })
      .catch(function(err) {
        swal('Thất bại', err, 'warning')
      })
    });
  });


  $('.cancelHoadon').on('click', function() {
    swal({
      title: 'Bạn có muốn hủy hóa đơn này?',
      text: 'Hóa đơn này sẽ bị xóa',
      type: 'warning',
      showCancelButton: true,
      confirmButtonColor: '#e1300e',
      confirmButtonText: 'Chấp nhận!',
      closeOnConfirm: false
    }, function() {
      angular.element('#angularPart').scope().confirmCancelHoadon()
      .then(function (res) {
        // swal('Đã khóa!', 'Khóa thành công', 'success');
        console.log(res)
        swal({
          title: 'Đã Hủy!',
          text: 'Hủy thành công',
          type: 'success'
        }, function () {
          window.location = "/trasua/admin/danhsachdonhang";
          
        })
      })
      .catch(function(err) {
        swal('Thất bại', err, 'warning')
      })
    });
  });


  $('.cancelDondh').on('click', function() {
    swal({
      title: 'Bạn có muốn hủy đơn đặt hàng này?',
      text: 'Đơn này sẽ bị hủy',
      type: 'warning',
      showCancelButton: true,
      confirmButtonColor: '#e1300e',
      confirmButtonText: 'Chấp nhận!',
      closeOnConfirm: false
    }, function() {
      angular.element('#angularPart').scope().confirmCancelDondh()
      .then(function (res) {
        // swal('Đã khóa!', 'Khóa thành công', 'success');
        console.log(res)
        swal({
          title: 'Đã Hủy!',
          text: 'Hủy thành công',
          type: 'success'
        }, function () {
          window.location = "danhsachdondathang";
          
        })
      })
      .catch(function(err) {
        swal('Thất bại', err, 'warning')
      })
    });
  });

  $('.doneNguyenlieu').on('click', function() {
    swal({
      title: 'Lưu thay đổi?',
      text: 'Thay đổi này sẽ được lưu',
      type: 'warning',
      showCancelButton: true,
      confirmButtonColor: '#e1300e',
      confirmButtonText: 'Chấp nhận!',
      closeOnConfirm: false
    }, function() {
       angular.element('#angularPart').scope().confirmDone()
      .then(function (res) {
        
        swal({
          title: 'Lưu thành công!',
          text: '',
          type: 'success'
        }, function () {
          window.location = "danhsachnguyenlieu";
          
        })
      })
      .catch(function(res) {
        swal(res, 'Vui lòng kiểm tra lại', 'warning')
      })
      
    });
  });


  $('.doneSize').on('click', function() {
    swal({
      title: 'Lưu thay đổi?',
      text: 'Thay đổi này sẽ được lưu',
      type: 'warning',
      showCancelButton: true,
      confirmButtonColor: '#e1300e',
      confirmButtonText: 'Chấp nhận!',
      closeOnConfirm: false
    }, function() {
       angular.element('#angularPart').scope().confirmDoneSize()
      .then(function (res) {
        
        swal({
          title: 'Lưu thành công!',
          text: '',
          type: 'success'
        }, function () {
          window.location = "chitietsize";
          
        })
      })
      .catch(function(res) {
        swal(res, 'Vui lòng kiểm tra lại', 'warning')
      })
      
    });
  });

  

  $('.changePassword').on('click', function() {
    swal({
      title: 'Lưu thay đổi?',
      text: 'Thay đổi này sẽ được lưu',
      type: 'warning',
      showCancelButton: true,
      confirmButtonColor: '#e1300e',
      confirmButtonText: 'Chấp nhận!',
      closeOnConfirm: false
    }, function() {
       angular.element('#angularPart').scope().confirmChangePass()
      .then(function (res) {
        
        swal({
          title: 'Thay đổi thành công!',
          text: '',
          type: 'success'
        }, function () {
          window.location = "login";
          
        })
      })
      .catch(function(res) {
        swal(res, 'Vui lòng kiểm tra lại', 'warning')
      })
      
    });
  });



  $('.LockProduct').on('click', function() {
    swal({
      title: 'Bạn có muốn khóa sản phẩm này?',
      text: 'Sản phẩm này sẽ bị khóa tạm thời',
      type: 'warning',
      showCancelButton: true,
      confirmButtonColor: '#e1300e',
      confirmButtonText: 'Chấp nhận!',
      closeOnConfirm: false
    }, function() {
      angular.element('#editProduct').scope().confirmLock()
      .then(function (res) {
        // swal('Đã khóa!', 'Khóa thành công', 'success');
        swal({
          title: 'Đã khóa!',
          text: 'Khóa thành công',
          type: 'success'
        }, function () {
          window.location = res;
          
        })
      })
      .catch(function(err) {
        swal('Thất bại', 'Có lỗi xảy ra vui lòng kiểm tra lại', 'warning')
      })
    });
  });


  $('.UnlockProduct').on('click', function() {
    swal({
      title: 'Mở sản phẩm này?',
      text: 'Sản phẩm này sẽ được mở',
      type: 'warning',
      showCancelButton: true,
      confirmButtonColor: '#e1300e',
      confirmButtonText: 'Chấp nhận!',
      closeOnConfirm: false
    }, function() {
       angular.element('#editProduct').scope().confirmUnlock()
      .then(function (res) {
        
        // swal('Mở thành công!', '', 'success');
        swal({
          title: 'Mở thành công!',
          text: '',
          type: 'success'
        }, function () {
          window.location = res;
          
        })
      })
      .catch(function(err) {
        swal('Thất bại', 'Có lỗi xảy ra vui lòng kiểm tra lại', 'warning')
      })
      
    });
  });

  $('.DeleteProduct').on('click', function() {
    swal({
      title: 'Xoá sản phẩm này?',
      text: 'Sản phẩm này sẽ bị xóa vĩnh viễn',
      type: 'warning',
      showCancelButton: true,
      confirmButtonColor: '#e1300e',
      confirmButtonText: 'Chấp nhận!',
      closeOnConfirm: false
    }, function() {
       angular.element('#editProduct').scope().confirmDelete()
      .then(function (res) {
        swal({
          title: 'xóa thành công!',
          text: '',
          type: 'success'
        }, function () {
          window.location = "../danhsachsanpham";
          
        })
      })
      .catch(function(err) {
        swal('Thất bại', err, 'warning')
      })
      
    });
  });


  $('.demo6').on('click', function() {
    swal({
      title: 'Are you sure?',
      text: 'You will not be able to recover this imaginary file!',
      type: 'warning',
      showCancelButton: true,
      confirmButtonColor: '#DD6B55',
      confirmButtonText: 'Yes, delete it!',
      cancelButtonText: 'No, cancel plx!',
      closeOnConfirm: false,
      closeOnCancel: false
    }, function(isConfirm) {
      if (isConfirm) {
        swal('Deleted!', 'Your imaginary file has been deleted!', 'success');
      } else {
        swal('Cancelled', 'Your imaginary file is safe :)', 'error');
      }
    });
  });

  $('.demo7').on('click', function() {
    swal({
      title: 'Sweet!',
      text: 'Here\'s a custom image.',
      imageUrl: 'images/avatar.jpg'
    });
  });

  $('.demo8').on('click', function() {
    swal({
      title: 'HTML <small>Title</small>!',
      text: 'A custom <span style=\"color:#F8BB86\">html<span> message.',
      html: true
    });
  });

  $('.demo9').on('click', function() {
    swal({
      title: 'An input!',
      text: 'Write something interesting:',
      type: 'input',
      showCancelButton: true,
      closeOnConfirm: false,
      animation: 'slide-from-top',
      inputPlaceholder: 'Write something'
    }, function(inputValue) {
      if (inputValue === false) {
        return false;
      }
      if (inputValue === '') {
        swal.showInputError('You need to write something!');
        return false;
      }
      swal('Nice!', 'You wrote: ' + inputValue, 'success');
    });
  });

  $('.demo10').on('click', function() {
    swal({
      title: 'Ajax request example',
      text: 'Submit to run ajax request',
      type: 'info',
      showCancelButton: true,
      closeOnConfirm: false,
      showLoaderOnConfirm: true
    }, function() {
      setTimeout(function() {
        swal('Ajax request finished!');
      }, 2000);
    });
  });

})(jQuery);
